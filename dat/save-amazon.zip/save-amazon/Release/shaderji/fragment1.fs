#version 330 core

out vec4 FragColor;

uniform vec3 color;
uniform sampler2D Ourtexture;
uniform vec2 change;

in vec2 TexCord;

void main()
{	
	//FragColor = vec4(color,1.0f);
	FragColor = texture(Ourtexture, TexCord+change);
	//FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), 0.2)
}